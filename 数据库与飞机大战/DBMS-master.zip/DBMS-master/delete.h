#include<string>
#include<iostream>
using namespace std;
void delete_sql( string *s);
int  analysis_se(string *s,string *condition);
int find_ta(string ch,int *ex);
void change(string s,char *c);
void move(int *ex,string *str);

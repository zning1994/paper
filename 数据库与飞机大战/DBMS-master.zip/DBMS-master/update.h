#include<string>
#include<iostream>
using namespace std;
void updata(string *s);
void get_date(string *str,int *ex);
void change_s_c(string s,char *c);
void change_date(int *ex,string *str);

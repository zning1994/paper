#include<string>
using namespace std;
#define ZHIDUAN_PATH "E:\\zhiduan.dat"
#define DATE_PATH  "E:\\date.mysql"
#define DATE1_PATH "E:\\date1.mysql"
#define ZHIDUAN1_PATH "E:\\zhiduan1.dat"
struct zhiduan
{
	char  name[10];
	char type[10];
	int size;
	// bekey;
    //char beempty;
    //char useful;

};
struct set
{
	string first;
	string end;
};
#define ZHIDUAN_PATH "E:\\zhiduan.dat"
#define DATE_PATH  "E:\\date.mysql"
#define DATE1_PATH "E:\\date1.mysql"
#define ZHIDUAN1_PATH "E:\\zhiduan1.dat"



#include<string>
#include<iostream>
#include<fstream>
using namespace std;
void drop(string *s);
int find(string s,int *ex);
void delete_ta(int *ex);

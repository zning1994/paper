#include<string>
#include<fstream>
#include<iostream>
using namespace std;
void insert(string *s);
void savadata(char *str,int lenth,string *s,int ex);
void  analysis_in (string *s,int lenth,string *str);

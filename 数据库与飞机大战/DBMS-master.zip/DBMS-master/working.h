#include<string>
#include<iostream>
#include"create.h"
#include"insert.h"
#include"select.h"
#include"delete.h"
#include"update.h"
#include"drop.h"
using namespace std;
void wdelete(string *s);
void winsert(string *s);
void wupdate(string *s);
void wselect(string *s);
void wcreate(string *s);
void wdrop(string *s);

void look();

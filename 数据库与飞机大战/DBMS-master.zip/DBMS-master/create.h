#include<string>
#include<iostream>
#include<fstream>
using namespace std;
void create_db(string *s);
void create_ta(string *s);
string  analysis_ta(string *s);
int look_ta();
bool find_cr(string s);